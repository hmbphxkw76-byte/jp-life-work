# 日本特定技能司机与物流行业监测报告（基线版）

> **版本**：v2026.11.11（首期基线）　**数据基准日**：2026-11-11
> **受众定位**：拟通过特定技能（SSW）签证赴日从事货运司机工作的读者
> **来源规则**：日文官方一手 + 英文权威优先；中文来源仅作线索，引用均回溯日/英原文

**本次运行变量记录**

```text
{{REGION}}               = 日本
{{TOPIC}}                = 特定技能司机 · 物流行业 · 智能驾驶展望
{{CURRENT_DATE}}         = 2026-11-11
{{PREVIOUS_REPORT_PATH}} = （空 → 首期基线）
{{REPORT_VERSION}}       = v2026.11.11
{{FRESHNESS_PRIORITY}}   = 近12个月优先，超24个月标注年份
```

**【已修正事实清单】**：首期为空。本次基线已发现的官方数据冲突（受入上限 22,100 vs 24,500、签证费口径等）暂列"待复核清单"，待次期核实修正后逐条补记于此。

---

## 数据变更摘要（首期基线确立，14 项追踪指标首取值）

| # | 指标 | 上一版值 | 本次值（来源/年份） | 变化性质 |
|---|---|---|---|---|
| 1 | 特定技能在留者总数（分野别） | 待基线确立 | 未取得官方最新值（ISA 统计月报未直接核阅）→ 待复核 | 首期未确立 |
| 2 | 「自動車運送業」分野要件 | 待基线确立 | 卡车：评价试验（ClassNK）合格＋第一种驾照＋JFT-Basic A2.2／JLPT N4 以上（ISA，2026） | 基线确立 |
| 3 | 技能試験・日本語試験日程 | 待基线确立 | ClassNK CBT 随时可考、中国大陆无考场；JLPT 中国 2026 年 7/12 两次（ClassNK、neea.cn，2026） | 基线确立 |
| 4 | 司机缺口 | 待基线确立 | 不采取措施下 2024 年度约 14%、2030 年度约 34%；再检证：2030 年度平均 7%／最大 25%（MLIT 白書2025／再检证资料，2025–2026） | 基线确立（口径差异见正文） |
| 5 | 運輸業月均工资 | 待基线确立 | 运输业·邮政业现金给与总额 341,158 円/月（+4.9%），2026 年 9 月分（厚労省毎月勤労統計，2026） | 基线确立 |
| 6 | 求人抽样 | 待基线确立 | 东京圈 22–45 万円／大阪圈 28–40.5 万円／地方 25–36 万円（聚合平台转载，2026，口径见正文） | 基线确立 |
| 7 | 物流倒産件数 | 待基线确立 | FY2025 道路货物运输业 321 件（TDB，2026）；历年口径 308 件（TSR，2026） | 基线确立（双口径并列） |
| 8 | 运赁指数 | 待基线确立 | 日银 SPPI 道路货物运输 113.3（同比+4.6%，2026-09）；WebKit 成约运赁指数 142（2026-10） | 基线确立 |
| 9 | 「2024年問題」对策 | 待基线确立 | トラック适正化二法公布（2025-06-11）；适正原价检讨会 2026 年已开 4 次（MLIT，2026） | 基线确立 |
| 10 | L4 自动驾驶进展 | 待基线确立 | 特定自动运行许可累计 12 件；新东名 L4 卡车公道实证中；《モビリティ・ロードマップ2026》发布（NPA／デジタル庁，2026） | 基线确立 |
| 11 | 物流企业外国人雇佣 | 待基线确立 | 佐川急便 2025 年起以特定技能接收越南司机（业界首批）（输送经济新闻，2025） | 基线确立 |
| 12 | 登録支援機関 | 待基线确立 | 支援月额行情 2–4 万円/人、登录机构逾 8,000 家（第三方，2026）；登录手续费官方 28,400 円 | 基线确立 |
| 13 | 中国中介渠道 | 待基线确立 | 路径＝商务部资质对外劳务合作企业＋日方送出机关体系（ssw.go.jp 中文页，2026）；资质查询入口已核实 | 基线确立 |
| 14 | 驾照路径与费用 | 待基线确立 | 外免切替 2025-10 严格化（知识确认合格率 42.8%）；普通 MT 教习约 40 万円、大型（持中型）约 21.4 万円（2026 示例） | 基线确立 |

---

## 一、核心结论（摘要）

1. **窗口已开但名额有限**：「自動車運送業」分野 2024-12-19 起正式接收特定技能 1 号外国人，五年受入上限存在 **22,100 人 vs 24,500 人** 两组官方数字并存（详见待复核清单），相对 84 万现役司机的行业规模属于"高确定性、但窄口径"的进入窗口。[Source: https://www.moj.go.jp/isa/policies/ssw/automobiletransportation, 2026; https://www.ssw.go.jp/cn/about/visa/automobile_transportation_business_1/, 2026]
2. **中国大陆考生面临"无考场"现实**：ClassNK 技能試験 CBT 与 JFT-Basic 的实施地均**不含中国大陆**，中国考生实际路径为赴第三国考试或在日本国内受验，日语考试只能走 JLPT（每年 7 月、12 月两次）。[Source: https://sswt-portal.classnk.or.jp/area?tab=3, 2026; https://www.prometric-jp.com/zh-CHS/ssw/, 2026; https://jlpt.neea.cn/faq.html, 2026]
3. **供需缺口决定雇主付费意愿**：国交省再检证将 2030 年度卡车运力缺口从旧估 34% 修正为"对策下平均约 7%／最大约 25%"，2026 年 8 月司机有效求人倍率高达 **2.54**（全产业 1.06）。薪资端运输业月均现金给与 34.1 万円（同比+4.9%），但司机绝对收入仍低于全产业均值。[Source: https://www.mlit.go.jp/seisakutokatsu/freight/content/001984794.pdf, 2025; https://www.mhlw.go.jp/content/11602000/001753011.pdf, 2026; https://www.mhlw.go.jp/toukei/itiran/roudou/monthly/r08/2609p/2609p.html, 2026]
4. **运价→工资传导已启动但不完全**（推断）：2026 春斗卡车业加薪率 3.85% 低于全产业 5.02%，但全ト协调查显示大型司机月薪已达 39.5 万円（+4%）；头部企业（佐川、雅玛多）待遇公告显著高于行业均值。**此传导判断为推断，非官方结论。**[Source: https://logishift.net/2026/08/06/post-7782/, 2026; https://www.jil.go.jp/kokunai/blt/backnumber/2026/06/blm_sanbetsu.html, 2026]
5. **自动驾驶暂不构成就业威胁**（推断）：L4 现阶段限定"深夜·限定区间·路车协调"的新东名约 100km 实证，商用化目标在 2027–2028 年度以后，且首波聚焦幹線运送；市内配送司机的替代节奏预计显著更慢。**全部为推断。**[Source: https://www.digital.go.jp/assets/contents/node/basic_page/field_ref_resources/2415ad00-6a79-4ebc-8fb1-51a47b1b0552/11045673/20260721_meeting_mobility_01.pdf, 2026]
6. **落地最大风险在驾照与中介**：中国驾照外免切替 2025-10 起大幅严格化（技能确认合格率仅 13.1%），办理路径建议优先"特定活动（准备）入境＋在日直考"；招募必须走商务部资质企业。[Source: https://www.police.pref.chiba.jp/menkyoka/licence_info-11.html, 2025; https://www.moj.go.jp/isa/applications/procedures/16-1, 2026]

---

## 二、特定技能制度与签证路径

### 2.1 制度框架（截至 2026-11-11）

- **特定技能 1 号**：在留期间合计上限 5 年、不可携家属；**2 号**：无上限、可携配偶子女。[Source: https://www.ssw.go.jp/cn/about/visa/, 2026]
- **分野规模**：1 号可从事 19 个分野、2 号 11 个（出入国在留管理庁中文版）。[Source: https://www.ssw.go.jp/cn/about/visa/, 2026]
- **「自動車運送業」分野**：2024-03-29 阁议决定新增（同批：铁道、林业、木材产业），监管省厅为**国土交通省**；2024-12-19 上乗せ基准告示施行后正式开始接收；分野运用方针已于 2026-01-23 重新阁议决定。[Source: https://www.moj.go.jp/isa/applications/ssw/2024.03.29.kakugikettei.html, 2024–2026; https://www.moj.go.jp/isa/policies/ssw/automobiletransportation, 2026]
- **受入上限（冲突并列）**：
  - 22,100 人（2024 年 4 月–2029 年 3 月末，ISA 自動車運送業分野页）[Source: https://www.moj.go.jp/isa/policies/ssw/automobiletransportation, 2026-10-09 现在]
  - 24,500 人（卡车/出租车/巴士合计，SSW 官网中文页）[Source: https://www.ssw.go.jp/about/visa/automobile_transportation_business_1/, 2026]
  - 两组官方数字并存，未辨析差异（疑为不同时点修订或含/不含某岗位），列入待复核。
- **⚠️ 本分野仅设 1 号**：卡车司机不存在 2 号路径；1→2 号转换、育成就劳制度是否覆盖本分野"现时点未定"。[Source: https://www.mlit.go.jp/jidosha/content/002004573.pdf, 2026-06]

### 2.2 「自動車運送業」分野人材基准

| 岗位 | 技能要件 | 日语要件 | 备注 |
|---|---|---|---|
| 卡车司机（监测重点） | 评价试验（卡车）合格 ＋ 第一种驾照 | JFT-Basic A2.2 相当 **或** JLPT N4 以上 | 技能实习 2 号良好修業者免日语 |
| 出租车/巴士司机 | 评价试验 ＋ **第二种驾照** ＋ 新任驾驶员研修 | 原则 JLPT N3（CEFR B1）；雇主落实 B1 学习计划等措施可放宽至 N4/A2.2 | 课加条件第 9/10/11 条 |

[Source: https://www.moj.go.jp/isa/policies/ssw/automobiletransportation, 2026]

- 业务范围：卡车/出租车/巴士驾驶员（限事业用车辆）及附带业务。
- 健康检查义务条文：本次未在 ISA 分野页核实到统一规定 → 待复核。

### 2.3 试验信息（技能試験 + 日本語試験）

**技能試験**（实施主体：一般财团法人日本海事协会 ClassNK）
- 形式：CBT 或纸面；学科 30 问（○×）＋实技 20 问（三选一），共 80 分钟，各正答率 ≥60% 合格；试题日语（附注音）。[Source: https://www.mlit.go.jp/jidosha/content/001851696.pdf, 2024-12 施行]
- CBT 无固定考期、考位有空随时可考；实施地：日本、印度、印尼、乌兹别克、吉尔吉斯、柬埔寨、斯里兰卡、泰国、尼泊尔、巴基斯坦、孟加拉、菲律宾、马来西亚、缅甸、蒙古、老挝、越南、塔吉克——**中国大陆无考场**；出差考试限企业申请（海外 50 枠起）。[Source: https://sswt-portal.classnk.or.jp/area?tab=3, 2026]
- 受验费：**日本国内 6,500 円（税抜）、海外 US$45**（2026-09-01 起改定）；合格证明书发行手续费 15,000 円（税抜）；合格证有效期 10 年。[Source: https://sswt-portal.classnk.or.jp/news/25, 2026]
- 官方免费样本题在 ClassNK Portal 公开（声明与实考同源）。[Source: https://sswt-portal.classnk.or.jp/area?tab=3-1, 2026]
- 全日本トラック协会发布面向外国人的学習用テキスト。[Source: https://jta.or.jp/member/driver/ssw_text.html, 2026]

**日本語試験**
- JFT-Basic：随時 CBT，海外 14 国（Prometric 中文页）／27 都市＋日本国内 10 都道府县——**中国大陆不在实施地**；2026-08 起增判 A1/A2.1（育成就劳对应）。[Source: https://www.prometric-jp.com/zh-CHS/ssw/, 2026; https://www.jpf.go.jp/jft-basic/report/pdf/2025-12-202601.pdf, 2026]
- JLPT：中国大陆每年 2 回（2026 年：7 月 5 日、12 月 6 日），**N4 报名费 450 元人民币**（N1/N2 550 元）——中国考生实际主路径。[Source: https://jlpt.neea.cn/faq.html, 2026]

### 2.4 申请流程与费用

1. 海外申请者先以**「特定活动」（特定自动车运送业准备）**入境（2025-02-17 起受理；卡车最长 6 个月），办理驾照（外免切替）与研修——未取得日本驾照则**不能**转入特定技能 1 号；变更审查期可特例在留最长 2 个月。[Source: https://www.moj.go.jp/isa/applications/procedures/16-1, 2026]
2. 雇主代办在留资格认定证明书（COE）：**手续费免费、标准审查 1–3 个月** → 驻外使领馆签证 → 入境。[Source: https://www.moj.go.jp/isa/applications/procedures/16-1, 2026]
3. 签证费：2026-07-01 起改定——单次有效约 **15,000 円**、多次约 30,000 円（当地货币缴纳）。冲突并列：驻沈阳总领馆旧页为 200 元人民币＋受理后第 5 个工作日发证（年份未标注）。[Source: https://www.mofa.go.jp/mofaj/toko/visa/tetsuzuki/pagew_000001_02672.html, 2026-06-24 更新; https://shenyang.cn.emb-japan.go.jp, 年份未标注]
4. 在留期间更新/变更许可手续费 5,500 円。[Source: https://www.moj.go.jp/isa/11_00108.html, 2026]

### 2.5 登録支援機関

- 职责：代雇主实施"义务性支援 10 项目"（事前指导、接送、住房·生活契约、生活指导、陪同行政手续、日语学习机会、咨询处理、交流促进、转职支援、每 3 个月以上面谈·通报）；不得再委托。[Source: https://www.moj.go.jp/isa/policies/ssw/supportssw.html, 2026]
- 登录要件：须能实施支援计划全部项目；登录 5 年有效，手续费新登录 **28,400 円**／更新 11,100 円；本分野受托支援机关还须加入国交省协议会（免费）。[Source: 同上; https://www.mlit.go.jp/jidosha/content/002004573.pdf, 2026]
- 市场行情（官方不定价；第三方 2026-04 更新）：初期 0–10 万円＋**月额 2–4 万円/人**，登录机构逾 8,000 家；月额 1 万円以下属异常低价。[Source: https://foreignworker-guide.com/articles/how-to-choose-support-agency/, 2026]（推断性经验值，非官方定价）

### 2.6 制度口径对比（术语不混用提示）

| 维度 | 特定技能（SSW）1号 | 特定技能 2号 | 技能实习 | 特定活动（本分野准备用） |
|---|---|---|---|---|
| 在留期间 | 合计 5 年上限 | 无上限 | 原则最长 3 年（2025 年制度改正后口径待复核） | 卡车最长 6 个月 |
| 家属 | 不可 | 可（配偶子女） | 不可 | 不可 |
| 定位 | 即战力劳力 | 更高熟练度 | 人材育成/技能转让目的 | 驾照·研修过渡 |

- SSW 数据行：[Source: https://www.ssw.go.jp/cn/about/visa/, 2026]；特定活动行：[Source: https://www.moj.go.jp/isa/applications/procedures/16-1, 2026]
- ⚠️ 技能实习、特定技能 2 号分野适用性的完整官方口径本次未逐项核实（推断列），完整对比表待次期补全 → 待复核。引用数据时严禁将技能实习统计与特定技能混算。

---

## 三、司机供需与薪资待遇（最高优先级）

### 3.1 供需缺口（口径差异并列呈现）

| 指标 | 数值 | 口径 |
| --- | --- | --- |
| [2024 年度运力不足](https://www.mlit.go.jp/hakusyo/mlit/r06/hakusho/r07/html/n1112000.html "来源：https://www.mlit.go.jp/hakusyo/mlit/r06/hakusho/r07/html/n1112000.html, 2025") | 约 14%（14.2%/约 4 亿吨） | 不采取对策情形，"已基本消化" |
| [2030 年度缺口（旧估）](https://www.mlit.go.jp/hakusyo/mlit/r06/hakusho/r07/html/n1112000.html "来源：https://www.mlit.go.jp/hakusyo/mlit/r06/hakusho/r07/html/n1112000.html, 2025") | 约 34% | 不采取对策 |
| [2030 年度缺口（再检证）](https://www.mlit.go.jp/seisakutokatsu/freight/content/001984794.pdf "来源：https://www.mlit.go.jp/seisakutokatsu/freight/content/001984794.pdf, 2025；https://www.jil.go.jp/event/ro_forum/20260529/houkoku/01-keynote-shuto.html, 2026") | **平均约 7%／最大约 25%**（无法运送 72 亿吨） | 采取官民对策后修正 |
| [现役事业用卡车司机](https://www.magazine.mlit.go.jp/interview/vol50-1-c-1/ "来源：https://www.magazine.mlit.go.jp/interview/vol50-1-c-1/, 2024") | 约 84 万人 | 干线运输事业用（2024，>24 个月标注） |
| [有效求人倍率](https://www.mhlw.go.jp/content/11602000/001753011.pdf "来源：https://www.mhlw.go.jp/content/11602000/001753011.pdf, 2026") | **2.54**（汽车驾驶业）vs 全产业 1.06 | 2026 年 8 月 |
| [年龄结构](https://www.mlit.go.jp/hakusyo/mlit/r06/hakusho/r07/html/n1111000.html "来源：https://www.mlit.go.jp/hakusyo/mlit/r06/hakusho/r07/html/n1111000.html, 2025") | 运输业 55 岁以上占 33.9%、29 岁以下仅 11.0%（全产业 16.9%） | 2024 年劳动力调查 |
| [劳动强度](https://www.jil.go.jp/event/ro_forum/20260529/houkoku/01-keynote-shuto.html "来源：https://www.jil.go.jp/event/ro_forum/20260529/houkoku/01-keynote-shuto.html, 2025 / 2026") | 大型司机年均劳动 2,544 小时（全产业 2,136）；年间拘束时间上限 2024 年起 3,516→3,300 小时 | 2023 年/新基准 |
| [每运次拘束](https://www.mlit.go.jp/report/press/tokatsu02_hh_000084.html "来源：https://www.mlit.go.jp/report/press/tokatsu02_hh_000084.html, 2026") | 10 小时 13 分（同比-1h33m），其中荷待·装卸 2h02m | FY2025 年 4–8 月平常期 |

⚠️ 提示词指定的 MLIT「トラックドライバー不足実態調査」专项调查的不足人数精确值与"49 岁以下占比"未命中原文页（白書/JILPT 为替代口径）→ 待复核清单。

### 3.2 薪资统计（厚労省毎月勤労統計，2026 年 9 月分速报，2026-11-06 公布）

| 项目 | 运输业·邮政业（5 人以上事业所） | 全产业对照 |
|---|---|---|
| 现金给与总额（月） | **341,158 円（+4.9%）** | 311,409 円（+4.6%） |
| 固定给与 | 334,957 円（+4.5%） | — |
| 所定内给与 | 292,610 円（+5.4%） | — |
| 所定外给与（加班等） | 42,347 円（-0.6%） | — |
| 一般劳动者总额 | 386,399 円（+4.7%） | — |

口径：名义月额、**未含年度赏与**；"运输业·邮政业"为产业中分类，未细分子行业。[Source: https://www.mhlw.go.jp/toukei/itiran/roudou/monthly/r08/2609p/xls/2609c01p.xlsx, 2026]
年龄别年收（2023，白書）：大型司机 485 万円／中小型 438 万円（全产业 507 万円）。[Source: https://www.mlit.go.jp/hakusyo/mlit/r06/hakusho/r07/html/n1111000.html, 2025]
全ト协 2026 年版工资调查（4,624 社中 589 社回答）：男性大型司机月薪 39.5 万円（+4%）、全职务平均 35.98 万円（+5.3%）、含奖金 41.64 万円（+7.1%）。[Source: https://logishift.net/2026/08/06/post-7782/, 2026]（经 LogiShift 转引，原件待复核）

### 3.3 求人抽样（岗位 × 地域分层；月给口径含诸手当）

⚠️ HelloWork/Indeed 原站反爬无法直抓，以下为聚合平台（求人Box 等）转载值，引用时应回溯至原企业求人页核对"各種手当"明细 → 待复核清单。

| 地域 | 企业·岗位 | 月给 | 备注 |
|---|---|---|---|
| 东京圈 | [第一自动车运送（世田谷，2t）](https://xn--pckua2a7gp15o89zb.com/運送業-トラックの仕事 "来源：https://xn--pckua2a7gp15o89zb.com/運送業-トラックの仕事, 2026") | 22 万–45 万円 | 赏与あり |
| 东京圈 | [东京台东区中型](https://en.genbars.jp/kw/all/中型ドライバー%20東京%20求人/ "来源：https://en.genbars.jp/kw/all/中型ドライバー%20東京%20求人/, 2026-11") | 346,650 円～ |  |
| 大阪圈 | [桑原服务（茨木，夜勤 4t）](https://en.genbars.jp/kw/all/中型ドライバー%20東京%20求人/ "来源：https://en.genbars.jp/kw/all/中型ドライバー%20東京%20求人/, 2026") | 36.5 万–40.5 万円 | 赏与昇给あり |
| 大阪圈 | [Marumasu 食品物流（东住吉，2t）](https://en.genbars.jp/kw/all/中型ドライバー%20東京%20求人/ "来源：https://en.genbars.jp/kw/all/中型ドライバー%20東京%20求人/") | 30 万円～ |  |
| 地方 | [朝日运输（富山射水，中/大型）](https://en.genbars.jp/kw/all/中型ドライバー%20東京%20求人/ "来源：https://en.genbars.jp/kw/all/中型ドライバー%20東京%20求人/") | 25 万–33.5 万円 | 无事故手当 |
| 地方 | [西本急送（广岛）](https://en.genbars.jp/kw/all/中型ドライバー%20東京%20求人/ "来源：https://en.genbars.jp/kw/all/中型ドライバー%20東京%20求人/") | 25 万–36 万円 |  |
| 地方 | [大富（福冈市，2t 便利店配送）](https://en.genbars.jp/kw/all/中型ドライバー%20東京%20求人/ "来源：https://en.genbars.jp/kw/all/中型ドライバー%20東京%20求人/") | 28.5 万–30.7 万円 |  |
| **特定技能专项** | [Mintoku Work（埼玉，「育成 Driver」）](https://mintoku.work/?specific_skills_industry=15 "来源：https://mintoku.work/?specific_skills_industry=15, 2026") | **265,020 円** | N3＋第一种免许、升给赏与あり |

企业待遇公告参考：佐川急便招聘面月收例 32 万円、年收 480 万起 [Source: https://www.trucknews.biz/article/r091138/, 2025]；雅玛多 SD 司机"年收 600 万円以上可"（例：30 岁·入社 5 年·月收 40 万円）[Source: https://www.kuronekoyamato.co.jp/ytc/corp/recruit/sales-driver/benefits-and-training.html, 2026]。

### 3.4 运赁（司机工资的行情基础）

- 日银企业向服务价格指数「道路货物运输」：2026-09 = 113.3（2020=100），**同比+4.6%**。[Source: https://www.dlri.co.jp/files/macro/666907.pdf, 2026（引日银 SPPI）]
- WebKit 成约运赁指数：2026-10 = **142**（同比+5pt）；并列：2026-09 = 143（LogiShift 口径）。[Source: https://cargo-news.online/news/detail.php?id=12653, 2026; https://logishift.net/stats/truck-freight-rate-index/, 2026]
- 标准运赁：令和 6 年告示第 209 号（2024-03）水准 **+8%** 并新增装卸费加算。[Source: https://jta.or.jp/member/kaisei_jigyoho/unchin_new.html, 2024]
- 价格转嫁率：2023-09 的 24.2% → 2025-09 的 **34.7%**（中小企业厅）。[Source: https://www.jil.go.jp/event/ro_forum/20260529/houkoku/01-keynote-shuto.html, 2026]

### 3.5 净收入参考模型（推断）

**模型输入参数（均官方来源）**

| 参数 | 数值 |
| --- | --- |
| [健康保险料率（协会けんぽ令和 8 年度，劳动折半）](https://www.kyoukaikenpo.or.jp/about/business/insurance_rate/rate_prefectures/r08/ "来源：https://www.kyoukaikenpo.or.jp/about/business/insurance_rate/rate_prefectures/r08/, 2026") | 东京 9.85%／大阪 10.13%＋子ども·子育て支援金 0.23%（2026-04 起全国） |
| [厚生年金](https://www.nenkin.go.jp/service/kounen/hokenryo/hoshu/20150515-01.html "来源：https://www.nenkin.go.jp/service/kounen/hokenryo/hoshu/20150515-01.html, 2026") | 18.3%、本人折半 9.15% |
| [雇用保险（一般事业，本人负担）](https://jsite.mhlw.go.jp/yamagata-roudoukyoku/koyouhoken-20260316.html "来源：https://jsite.mhlw.go.jp/yamagata-roudoukyoku/koyouhoken-20260316.html, 2026") | 0.5% |
| [源泉征收](https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2026/01.htm "来源：https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2026/01.htm, 2026") | 国税厅令和 8 年分税额表（2026-01 改定） |

**示例概算（月给总额 30 万円、东京、40 岁未满、单身无扶养——全部为推断）**：社保约 4.4 万円（健康保険折半约 1.5 万＋年金折半 2.7 万＋雇用 0.15 万）＋所得税约 0.44 万＋住民税约 0.85 万 → **到手约 24.3 万円/月**（入职首年无前年住民税约 25.2 万）。模型未含赏与、通勤手当等非课税/变动项；中国同岗到手收入对比因需中文来源回溯未建立 → 待次期补充。

---

## 四、物流行业态势

### 4.1 "2024年問題"后续

- 官方定调：2024 年度约 14% 运力缺口经官民对策"基本克服"；宅配件数 FY2024 约 50 亿个维持高位。[Source: https://www.mlit.go.jp/seisakutokatsu/freight/content/001984794.pdf, 2025]
- 未发生全国性停运，总合物流施策大纲记载"部分地区出现运输限制"；再配送率降至 7.6%（2026-04）。[Source: https://www.mlit.go.jp/report/press/tokatsu01_hh_001025.html, 2026]

### 4.2 物流倒産（双机构双口径并列）

| 统计机构 | 口径 | 数值 |
|---|---|---|
| [帝国データバンク](https://www.tdb.co.jp/report/bankruptcy/aggregation/20260408-bankruptfy2025/ "来源：https://www.tdb.co.jp/report/bankruptcy/aggregation/20260408-bankruptfy2025/, 2026") | FY2025（2025.4–2026.3） | 道路货物运输业 **321 件**＝史上第 4 高（前三位：2008 年度 371、FY2024 351、2009 年度 341）；其中人手不足倒产 55 件、物价高涨 91 件 |
| [东京商工リサーチ](https://www.tsr-net.co.jp/data/detail/1202864_1527.html "来源：https://www.tsr-net.co.jp/data/detail/1202864_1527.html, 2026") | 历年 2025 年 | 道路货运倒产 **308 件（-17.6%）**；2026 年 1–4 月 108 件（+11.3%），人手不足倒产 23 件创 2013 年统计以来新高 |

⚠️ 两个机构统计期间不同（事业年度 vs 历年），**不可直接比较或加总**。

### 4.3 运价与政策

- 运价谈判实施率：FY2022 68% → FY2024 74% → **FY2025 90%**；但收受达标准运价 8 成以上者仅约 35%。[Source: https://www.mlit.go.jp/report/press/jidosha04_hh_000361.html, 2026]
- 企业改定：佐川急便 2027-01-01 起宅配便平均 **+13.8%** [Source: https://www2.sagawa-exp.co.jp/newsrelease/detail/2026/1002_2672.html, 2026]；福山通运 2026-11 起较 FY2024 约 **+20%** [Source: https://logishift.net/2026/10/27/post-9951/, 2026]；雅玛多 2024-04 个人报价约 +2% [Source: https://www.yamato-hd.co.jp/english/news/2023/pdf/newsrelease_20240112_en01.pdf, 2024]。
- **トラック适正化二法**：2025-06-11 公布，国家设定"适正原价"，荷主与运送双方均不得低于该水平收付，公布后 3 年内施行；"适正原价设定检讨会"2026 年已开 4 次，年内拟出建言；2026-04 起禁止委托无许可"白牌卡车"（荷主罚 100 万円以下）。[Source: https://www.mlit.go.jp/jidosha/jidosha_mn4_000019.html, 2025–2026; https://www.mlit.go.jp/jidosha/jidosha_mn4_000020.html, 2026; https://wwwtb.mlit.go.jp/kinki/content/000365947.pdf, 2026]
- **运价→工资传导（推断声明）**：全日协调查大型司机月薪 +4% 表明转嫁已部分传导；但卡车业加薪率 3.85% 低于全产业 5.02% 表明传导不完全。两处判断均为**推断**。[Source: https://logishift.net/2026/08/06/post-7782/, 2026; https://www.jil.go.jp/kokunai/blt/backnumber/2026/06/blm_sanbetsu.html, 2026]

### 4.4 行业 M&A 与企业动态

- SGHD：2024-07 将名糖运输、ヒューテックノオリン纳入集团；2025 年度收购 Morrison；FY2026/3 上半期销售额 9,204 亿円（转引待核 IR 原件）。[Source: https://www.sg-hldgs.co.jp/ir/management/directormessage/, 2026]
- 日通：出售低收益资产资金投入 M&A。[Source: https://pdf.irpocket.com/C9147/doF3/OcDN/QgbQ.pdf, 2025]
- 政策支援：国交省依产业竞争力强化法认定"特别事业再编计划"；SMRJ 事业承继门户、政策金融公库承继 Matching 支援累计约 700 社（2022）。[Source: https://www.mlit.go.jp/jidosha/jidosha_tk5_000038.html; https://shoukei.smrj.go.jp/; https://www.jfc.go.jp/n/release/pdf/topics_220805a.pdf, 2022]
- **外国人雇佣动向**：佐川急便 2025 年以特定技能接收**越南司机**（业界首批案例之一）；2025-09 与 TDG 合办特定技能司机采用讲座。[Source: https://yuso.co.jp/20251014-12/, 2025; https://www.trucknews.biz/article/r091138/, 2025]

---

## 五、智能驾驶与未来展望

### 5.1 制度框架与实绩

- 等级口径：SAE L0–L4（日本政府文件注记采用）；L4＝限定区域内系统替代全部驾驶操作、无需驾驶人。[Source: https://www8.cao.go.jp/koutu/taisaku/r05kou_haku/zenbun/genkyo/topics/topic_1.html, 2023]
- 令和 4 年改正道交法（2022-04 施行）创设"特定自动运行许可"（无驾驶人公道运行，需都道府县公安委员会批准）。实绩：**截至 2026-05 许可累计 12 件**；2025 年度全国 60+ 地点实施实证（含有人驾驶辅助类）。[Source: https://www.npa.go.jp/bureau/traffic/selfdriving/index.html, 2026; https://www.digital.go.jp/assets/contents/node/basic_page/field_ref_resources/2415ad00-6a79-4ebc-8fb1-51a47b1b0552/11045673/20260721_meeting_mobility_01.pdf, 2026]
- 首辆 L4 车辆认证：2023-03-30 福井县永平寺町。[Source: https://www.mlit.go.jp/report/press/jidosha07_hh_000442.html, 2023]

### 5.2 官方时间表（《モビリティ・ロードマップ2026》，2026-07-21 数字社会推进会议决定）

- 2027 年度起社会实装；2030 年度前国内导入自动驾驶服务车辆 1 万台；2030 年代全球 AV 销量份额约 25%。[Source: 同上 PDF, 2026]
- 货运专项："2026 年以后在高速公路实现 L4 卡车社会实装"；企业口径无人卡车 2027 年度事业化、RoboTruck 2028 年度事业化；《総合物流施策大綱(2026-2030)》（2026-03 阁议）将自动驾驶卡车社会实装列为物流效率化支柱。[Source: 同上; https://www.cas.go.jp/jp/seisaku/nipponseichosenryaku/kaigi/dai5/shiryou3.pdf, 2026]
- 先行事业化地域 13 处（横滨、堺、神户、日立、盐尻、仙台、筑波、川崎、平冢、小松、爱知、京都、三丰），2027 年度事业化。[Source: https://www.digital.go.jp/assets/contents/node/basic_page/field_ref_resources/57849d08-38bd-4c73-be1d-7b38606a6ee0/c238efb2/20260324_meeting_mobility-working-group15_outline_09.pdf, 2026]

### 5.3 货车/干线实证

- 新东名骏河湾沼津 SA—滨松 SA 约 100km：2025-03 起深夜设"自动驾驶车优先车道"，L4 卡车公道实证进行中（合流支援、坠物/施工信息等路车协调）。[Source: 同路线图 PDF; https://www.mlit.go.jp/report/press/road01_hh_001845.html, 2024]
- 2024-11-05 丰田通商等 4 社＋五十铃/日野/三菱扶桑/UD 启动新东名大型卡车公道实证。[Source: https://www.isuzu-global.com/ja/newsroom/20241105_1.html, 2024]
- RoAD to the L4 主题 3（2021–2025）最终年度综合走行实证约 50,000km；物流 6 社参画：佐川、西浓运输、日通、日本邮便、福山通运、大和运输。[Source: https://www.road-to-the-l4.go.jp/activity/theme03/, 2025]
- T2：2026-03 以 L2 无人工介入完成关东—关西约 500km 行驶。[Source: 同路线图 PDF, 2026]
- 技术要件：L4 车辆需道运车两法"基准缓和认定"（远程型系统）＋走行环境条件付与；数据存 DSSAD；《自动驾驶车辆安全确保指南第 2 版》（2025-09 更新）。[Source: https://www.mlit.go.jp/jidosha/jidosha_tk7_000043.html, 2025]

### 5.4 对司机岗位的影响评估（**全部为推断**）

- **幹線运送 vs 市内配送替代节奏差异**：现行 ODD 限定"深夜·约 100km 干线区间·专用优先车道·路车协调"，商用化目标 2027–2028 年度以后——幹线夜行长途最先受影响；市内配送（接驳、装卸、复杂路况）预计远晚于干线，2030 年前难以规模化替代。此为基于 ODD 限制与路线图时间表的推断。
- 制度信号：无驾驶人运行以特定自动运行许可为前提；运行管理/远程监视人才育成列入 2026 路线图——**岗位将转型而非直接消失**（推断）。
- 时间线综合判断（推断）：2027 年度前对求职者的实质就业影响≈0；2027–2030 年干线 L4 试点扩大会影响干线夜行岗位增量；2030 年代市内配送替代才进入观察期。

---

## 六、就业落地建议（结论章）

### 6.1 考试准备路径

1. 技能試験：官方免费样本题（ClassNK Portal）＋全ト协学習用テキスト为唯一官方教材。[Source: https://sswt-portal.classnk.or.jp/area?tab=3-1, 2026; https://jta.or.jp/member/driver/ssw_text.html, 2026]
2. 日语：中国大陆考生主路径为 **JLPT N4**（每年 7/12 两次，450 元）；JFT-Basic 中国无考点（赴第三国时可选）。[Source: https://jlpt.neea.cn/faq.html, 2026; https://www.prometric-jp.com/zh-CHS/ssw/, 2026]
3. 考试地点策略（推断）：无考场于中国大陆 → 最现实路径为持有效中国驾照先赴日本以"特定活动"入境后国内受验（国内受验费 6,500 円），或赴越南/泰国等已有 CBT 考场的第三国。

### 6.2 招募渠道与中介资质

- 中国路径官方明示：**商务部批准资质的对外劳务合作企业**＋日方公共职业安定所（ハローワーク）。[Source: https://www.ssw.go.jp/cn/about/step/, 2026]
- 资质查询入口：商务部对外劳务合作企业名单 http://femhzs.mofcom.gov.cn/fecpmvc_zj/pages/fem/CorpLWList.html ；商务部提醒原文：无资质出国务工属违法。[Source: https://ao.mofcom.gov.cn/aqtz/art/2024/art_f0ce83f61c9240d39e775a23fcff8827.html, 2024]
- 非法中介特征（推断汇总）：无法提供商务部资质编号、要求前置大额"保证金"、承诺"免考包过"（技能試験为 ClassNK 统一实施，无免考通道）。

### 6.3 在留落地清单

- 在留卡：成田/羽田/中部/关西/新千岁机场当场发放；入住后 **14 日内**向市区町村住民登记（逾期可处 20 万円以下罚金，上陆 90 日不申报可取消在留资格）。[Source: https://www.moj.go.jp/isa/publications/faq/newimmiact_4_q-and-a_page3.html, 2026]
- 银行/手机：受入机关负有支援义务（住房确保、生活 orientiation 含银行/手机合同协助）。[Source: https://www.moj.go.jp/isa/policies/ssw/faq.html, 2026]
- 在线手续：持 My Number 卡可在留诸申请电子化；引越し转出/转入可在线办理。[Source: https://www.moj.go.jp/isa/about/guidance/?hl=en, 2026; https://www.digital.go.jp/policies/moving_onestop_service, 2025-2026]
- 生活咨询总入口：入管厅外国人生活支援 Portal。[Source: https://www.moj.go.jp/isa/support/portal/, 2026]

### 6.4 驾照路径（关键瓶颈）

| 路径 | 要点 | 费用/合格率 |
|---|---|---|
| [外免切替（持中国驾照）](https://www.police.pref.chiba.jp/menkyoka/licence_info-11.html "来源：https://www.police.pref.chiba.jp/menkyoka/licence_info-11.html, 2025；https://drivey.jp/blog/gaimen-kirikae-knowledge-test（转引警察庁）, 2025-2026") | 中国不在 29 国免除对象；知识确认 50 题正确率 90%＋技能确认（2025-10 严格化：新增横断步道课题、审查基准 70%） | 知识确认合格率 **42.8%**、技能确认 **13.1%**（2025 年 10–12 月，警察庁） |
| [在日新考取（普通 MT）](https://www.kesennuma-ds.com/price "来源：https://www.kesennuma-ds.com/price, 2026") | 18 岁～ | 约 **400,550 円**（税込示例，气仙沼中央自动车学校） |
| 中型 | 20 岁＋持其他驾照满 2 年 | 全国均价待核实 |
| [大型](https://www.iac-ds.co.jp/ajima/driver-license/oogata/ "来源：https://www.iac-ds.co.jp/ajima/driver-license/oogata/, 2026") | 21 岁＋满 3 年 | 约 **213,550 円**（持中型起，阿自马达 DS 示例） |

⚠️ 特定活动入境后未取得日本驾照则不能转特定技能 1 号——驾照是全流程的关键路径依赖。[Source: https://www.moj.go.jp/isa/applications/procedures/16-1, 2026]

### 6.5 风险提示与维权渠道

- 工资拖欠/不当解雇：劳动基准监督署受理；劳动条件咨询 Hotline **0120-811-610**（免费、匿名、多语言）。[Source: https://www.check-roudou.mhlw.go.jp/lp/hotline/, 2026]
- 劳动局外国人特别咨询·支援室（东京 FRESC 有中文页面）。[Source: https://jsite.mhlw.go.jp/tokyo-roudoukyoku/fresc_cn.html, 2026]
- 提示词中的"ITJ"窗口与"GFP"机构名称本次未能核实到官方原文 → 待复核清单。
- 警示（推断汇总）：警惕月给低于当地行情 20% 以上且无手当明细的特定技能转介合同；支援费异常低价（月额 1 万円以下）的登録支援機関可能降低法定支援质量。

---

## 七、数据可靠性与局限说明

**核验程度分级**
- A 级（官方一手直接引用）：制度框架、试验要件、签证费用、厚労省统计、MLIT 政策页、NPA/路线图、TDB/TSR 倒产。
- B 级（权威机构经第三方转引）：全ト协工资调查（经 LogiShift）、WebKit 运赁指数（经 Cargo News/LogiShift）、外免切替合格率（经 drivey.jp 转引警察庁）。
- C 级（平台抽样/转载）：求人样本（聚合平台转载，原企业页未逐一回溯）。

**已知口径冲突（双份保留）**
1. 受入上限 22,100 vs 24,500 人（两组官方数字）。
2. 签证费 15,000 円（MOFA 新规）vs 200 元人民币（沈阳领馆旧页）。
3. 2030 年度缺口 34%（不采取措施）vs 7%/25%（再检证修正）。
4. 倒产件数 FY2025 321 件（TDB 事业年度）vs 历年 308 件（TSR）。
5. WebKit 运赁指数 2026-10=142 vs 2026-09=143（不同发布渠道）。
6. L4 卡车商用化时间：政府环境整备口径"2026 年以后"vs 企业事业化口径 2027/2028 年度。

**未取得项（次期优先）**
- ISA 统计月报中特定技能在留者分野别总数（追踪表 #1）；MLIT 司机不足实态调查专项原文精确值；中国同岗到手收入对比；JFT-Basic 现行受验费；教习所全国均价。

**待复核清单（推荐复核入口）**
1. 受入上限差异 → isa.go.jp 分野页与 ssw.go.jp 对照核阅原文。
2. 中国大陆使领馆现行签证费 → 各领馆官网签证页。
3. MLIT 不足实态调查原文 → 国交省自动车局"貨物自動車運送事業の運賃等の適正化"专题页。
4. 全ト协工资调查原件 → 全日本トラック協会会员工资调查发布页。
5. "ITJ"/"GFP"官方名称 → 厚労省外国人雇佣对策相关页。
6. 本分野健康检查义务条文 → ISA 运用要领 PDF（001977550.pdf）。
7. ClassNK 国内受验费官方数额表 → sswt-portal.classnk.or.jp/news/25。
8. 日通司机加薪"月最大 5 万円"（2024-02 报道）→ 日通官方新闻室。
9. SGHD FY2026 上半期销售额 9,204 亿円 → SGHD IR 决算短信原件。
10. 技能实习/特定技能 2 号完整对比表官方口径 → isa.go.jp。

---

## 八、参考来源清单

1. [ISA 自動車運送業分野](https://www.moj.go.jp/isa/policies/ssw/automobiletransportation) — 出入国在留管理庁, 2026
2. [2024.3.29 阁议决定](https://www.moj.go.jp/isa/applications/ssw/2024.03.29.kakugikettei.html) — 出入国在留管理庁, 2024–2026
3. [特定技能总合支援站（中文）](https://www.ssw.go.jp/cn/about/visa/) — 2026
4. [特定技能步骤（中文）](https://www.ssw.go.jp/cn/about/step/) — 2026
5. [自動車運送業分野页面（中文）](https://www.ssw.go.jp/cn/about/visa/automobile_transportation_business_1/) — 2026
6. [ClassNK 考试门户（考场/样本题）](https://sswt-portal.classnk.or.jp/area?tab=3) — 2026
7. [ClassNK 受验费改定公告](https://sswt-portal.classnk.or.jp/news/25) — 2026
8. [国交省 实施要领 PDF](https://www.mlit.go.jp/jidosha/content/001851696.pdf) — 2024-12
9. [国交省 Q&A PDF](https://www.mlit.go.jp/jidosha/content/002004573.pdf) — 2026-06
10. [MOFA 签证手续费](https://www.mofa.go.jp/mofaj/toko/visa/tetsuzuki/pagew_000001_02672.html) — 2026-06
11. [ISA COE 申请手续](https://www.moj.go.jp/isa/applications/procedures/16-1) — 2026
12. [ISA 手数料一览](https://www.moj.go.jp/isa/11_00108.html) — 2026
13. [ISA 登録支援機関](https://www.moj.go.jp/isa/policies/ssw/supportssw.html) — 2026
14. [JFT-Basic 实施报告 PDF](https://www.jpf.go.jp/jft-basic/report/pdf/2025-12-202601.pdf) — 2026
15. [Prometric JFT-Basic 中文页](https://www.prometric-jp.com/zh-CHS/ssw/) — 2026
16. [JLPT 中国报名 FAQ](https://jlpt.neea.cn/faq.html) — 2026
17. [駐日ベトナム大使館技能試験页](https://www.vn.emb-japan.go.jp/itpr_ja/11_000001_02534_TokuteiginouShiken_Jidoushaunsou.html) — 2026
18. [MLIT 白書2025 需给 gap](https://www.mlit.go.jp/hakusyo/mlit/r06/hakusho/r07/html/n1112000.html) — 2025
19. [MLIT 白書2025 直面课题](https://www.mlit.go.jp/hakusyo/mlit/r06/hakusho/r07/html/n1111000.html) — 2025
20. [JILPT 劳动政策论坛基调讲演](https://www.jil.go.jp/event/ro_forum/20260529/houkoku/01-keynote-shuto.html) — 2026
21. [MLIT Grasp 杂志 vol50](https://www.magazine.mlit.go.jp/interview/vol50-1-c-1/) — 2024
22. [厚労省毎月勤労統計 2026 年 9 月分](https://www.mhlw.go.jp/toukei/itiran/roudou/monthly/r08/2609p/2609p.html) — 2026
23. [厚労省有効求人倍率 PDF](https://www.mhlw.go.jp/content/11602000/001753011.pdf) — 2026
24. [大和总研 SPPI 报告（引日银）](https://www.dlri.co.jp/files/macro/666907.pdf) — 2026
25. [Cargo News 成约运赁指数](https://cargo-news.online/news/detail.php?id=12653) — 2026
26. [LogiShift 运赁指数](https://logishift.net/stats/truck-freight-rate-index/) — 2026
27. [全ト协 标准运赁告示](https://jta.or.jp/member/kaisei_jigyoho/unchin_new.html) — 2024
28. [全ト协 SSW 学習テキスト](https://jta.or.jp/member/driver/ssw_text.html) — 2026
29. [MLIT 2030 年度物流需给再检证 PDF](https://www.mlit.go.jp/seisakutokatsu/freight/content/001984794.pdf) — 2025
30. [MLIT 拘束时间调查发布](https://www.mlit.go.jp/report/press/tokatsu02_hh_000084.html) — 2026
31. [MLIT 标准运赁实态调查](https://www.mlit.go.jp/report/press/jidosha04_hh_000361.html) — 2026
32. [MLIT 再配送率调查](https://www.mlit.go.jp/report/press/tokatsu01_hh_001025.html) — 2026
33. [帝国データバンク FY2025 倒产集计](https://www.tdb.co.jp/report/bankruptcy/aggregation/20260408-bankruptfy2025/) — 2026
34. [東京商工リサーチ 道路货运倒产](https://www.tsr-net.co.jp/data/detail/1202864_1527.html) — 2026
35. [SGHD 取缔役メッセージ](https://www.sg-hldgs.co.jp/ir/management/directormessage/) — 2026
36. [日通 企业价值提升 PDF](https://pdf.irpocket.com/C9147/doF3/OcDN/QgbQ.pdf) — 2025
37. [MLIT トラック适正化二法](https://www.mlit.go.jp/jidosha/jidosha_mn4_000019.html) — 2025
38. [MLIT 适正原价检讨会](https://www.mlit.go.jp/jidosha/jidosha_mn4_000020.html) — 2026
39. [MLIT 大臣要请（2025-04-08）](https://www.mlit.go.jp/page/kanbo01_hy_010172.html) — 2025
40. [近畿运输局 白牌卡车禁止 PDF](https://wwwtb.mlit.go.jp/kinki/content/000365947.pdf) — 2026
41. [佐川急便运价改定新闻稿](https://www2.sagawa-exp.co.jp/newsrelease/detail/2026/1002_2672.html) — 2026
42. [输送经济新闻：佐川越南特定技能司机](https://yuso.co.jp/20251014-12/) — 2025
43. [トラックニュース：特定技能采用讲座](https://www.trucknews.biz/article/r091138/) — 2025
44. [雅玛多 SD 招募制度](https://www.kuronekoyamato.co.jp/ytc/corp/recruit/sales-driver/benefits-and-training.html) — 2026
45. [雅玛多 HD 2024 改定公告（英文）](https://www.yamato-hd.co.jp/english/news/2023/pdf/newsrelease_20240112_en01.pdf) — 2024
46. [NPA 自動運転](https://www.npa.go.jp/bureau/traffic/selfdriving/index.html) — 2026
47. [モビリティ・ロードマップ2026（デジタル庁 PDF）](https://www.digital.go.jp/assets/contents/node/basic_page/field_ref_resources/2415ad00-6a79-4ebc-8fb1-51a47b1b0552/11045673/20260721_meeting_mobility_01.pdf) — 2026-07-21
48. [モビリティ WG 第 15 回资料](https://www.digital.go.jp/assets/contents/node/basic_page/field_ref_resources/57849d08-38bd-4c73-be1d-7b38606a6ee0/c238efb2/20260324_meeting_mobility-working-group15_outline_09.pdf) — 2026-03
49. [RoAD to the L4 主题 3](https://www.road-to-the-l4.go.jp/activity/theme03/) — 2025
50. [五十铃 新东名实证新闻稿](https://www.isuzu-global.com/ja/newsroom/20241105_1.html) — 2024
51. [国交省 L4 车辆认证发布](https://www.mlit.go.jp/report/press/jidosha07_hh_000442.html) — 2023
52. [国交省 道运法施行规则改正](https://www.mlit.go.jp/report/press/jidosha02_hh_000561.html) — 2023
53. [国交省 公道走行安全指南](https://www.mlit.go.jp/jidosha/jidosha_tk7_000043.html) — 2025
54. [経財諮問会議官民投资路线图资料](https://www.cas.go.jp/jp/seisaku/nipponseichosenryaku/kaigi/dai5/shiryou3.pdf) — 2026
55. [令和 5 年交通安全白書](https://www8.cao.go.jp/koutu/taisaku/r05kou_haku/zenbun/genkyo/topics/topic_1.html) — 2023
56. [协会けんぽ令和 8 年度料率](https://www.kyoukaikenpo.or.jp/about/business/insurance_rate/rate_prefectures/r08/) — 2026
57. [山形劳动局雇用保险料率](https://jsite.mhlw.go.jp/yamagata-roudoukyoku/koyouhoken-20260316.html) — 2026
58. [年金机构厚生年金料率](https://www.nenkin.go.jp/service/kounen/hokenryo/hoshu/20150515-01.html) — 2026
59. [国税厅令和 8 年分源泉税额表](https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2026/01.htm) — 2026
60. [千葉県警察 外免切替严格化](https://www.police.pref.chiba.jp/menkyoka/licence_info-11.html) — 2025
61. [drivey.jp 外免切替合格率（转引警察庁）](https://drivey.jp/blog/gaimen-kirikae-knowledge-test) — 2025-2026
62. [气仙沼中央自动车学校料金](https://www.kesennuma-ds.com/price) — 2026
63. [阿自马达 DS 大型学费](https://www.iac-ds.co.jp/ajima/driver-license/oogata/) — 2026
64. [厚労省 劳动条件咨询 Hotline](https://www.check-roudou.mhlw.go.jp/lp/hotline/) — 2026
65. [东京劳动局 FRESC 中文页](https://jsite.mhlw.go.jp/tokyo-roudoukyoku/fresc_cn.html) — 2026
66. [ISA 外国人生活支援 Portal](https://www.moj.go.jp/isa/support/portal/) — 2026
67. [商务部对外劳务合作企业名单提醒](https://ao.mofcom.gov.cn/aqtz/art/2024/art_f0ce83f61c9240d39e775a23fcff8827.html) — 2024
68. [MOFA 登録支援機関说明](https://www.mofa.go.jp/mofaj/ca/fna/ssw/jp/registration/) — 2026
69. [ISA 在留卡 FAQ](https://www.moj.go.jp/isa/publications/faq/newimmiact_4_q-and-a_page3.html) — 2026
70. [デジタル庁 引越しワンストップ](https://www.digital.go.jp/policies/moving_onestop_service) — 2025-2026
71. [foreignworker-guide 登録支援機関行情](https://foreignworker-guide.com/articles/how-to-choose-support-agency/) — 2026
72. [求人Box 运送业求人](https://xn--pckua2a7gp15o89zb.com/運送業-トラックの仕事) — 2026
73. [Mintoku Work 特定技能求人](https://mintoku.work/?specific_skills_industry=15) — 2026
74. [LogiShift 全ト协工资调查转引](https://logishift.net/2026/08/06/post-7782/) — 2026
75. [JILPT 春斗数据](https://www.jil.go.jp/kokunai/blt/backnumber/2026/06/blm_sanbetsu.html) — 2026

---

本报告为 v2026.11.11 动态更新版（基线版），数据基准 2026-11-11，全部引自日/英来源。
